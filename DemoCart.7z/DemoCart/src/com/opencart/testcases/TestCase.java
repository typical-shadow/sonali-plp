package com.opencart.testcases;

import java.io.File;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.opencart.pageobject.Homepage;
import com.opencart.pageobject.LoginPage;
import com.opencart.pageobject.Search;
import com.opencart.utilities.Helper;

public class TestCase extends TestBase {
	File file ;
	@Test(priority = 0)
	public void testStep1() throws Exception {
		Homepage home = new Homepage(driver);
		home.goToLogin(count++,pdfHelper);
		
		file = Helper.takeSnapShot(driver,"Step_"+count);
		expected = "Account Login";
		actual = driver.getTitle();
		if (expected.equals(actual)) {
			pdfHelper.addRow(count++, "Title should be "+"\""+expected+"\"", "Title is "+"\""+actual+"\"", 1, file);
		}
		else {
			pdfHelper.addRow(count++, "Title should be "+"\""+expected+"\"", "Title is "+"\""+actual+"\"", 2, file);
		}
		
		
		LoginPage login = new LoginPage(driver);
		login.performLogin("gawdechint9@gmail.com", "g@wde1998",count++,pdfHelper);
		String expected = "My Account";
		String actual = driver.getTitle();
		file = Helper.takeSnapShot(driver,"Step_"+count);
		if (expected.equals(actual)) {
			pdfHelper.addRow(count++, "Title should be "+"\""+expected+"\"", "Title is "+"\""+actual+"\"", 1, file);
		}
		else {
			pdfHelper.addRow(count++, "Title should be "+"\""+expected+"\"", "Title is "+"\""+actual+"\"", 2, file);
		}
			
		home = new Homepage(driver);
		home.getSearchBtn().click();
		expected = "Search";
		actual = driver.getTitle();
		file = Helper.takeSnapShot(driver,"Step_"+count);
		if (expected.equals(actual)) {
			pdfHelper.addRow(count++, "Title should be "+"\""+expected+"\"", "Title is "+"\""+actual+"\"", 1, file);
		}
		else {
			pdfHelper.addRow(count++, "Title should be "+"\""+expected+"\"", "Title is "+"\""+actual+"\"", 2, file);
		}
		
		
		
	}

	@Test( dataProvider = "getData", priority = 1)
	public void testStep2(Hashtable<String,String> tab) throws Exception {

		String productList = "//body/div[@id='product-search']/div[@class='row']/div[@id='content']/div[3]";
		Search search = new Search(driver);
//		search.performSearch("monitor", "      Monitors",count++,pdfHelper);
		search.performSearch(tab.get("pName"),tab.get("category"),count++,pdfHelper);
		Helper helper = new Helper(driver);

		if (helper.isElementPresent(By.xpath(productList))) {
			String productHeading = "/html[1]/body[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/div[1]/h4[1]/a[1]";

			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollTo(0,500);");
			
			file = Helper.takeSnapShot(driver,"Step_"+count);
			
			
			///dyanmic   
			expected = tab.get("expected");

			actual = driver.findElement(By.xpath(productHeading)).getText();

			if (expected.equals(actual)) {
				pdfHelper.addRow(count++,"Product should exist with name "+"\""+expected+"\"", "Product exists with name "+"\""+actual+"\"", 1,file);
			} else {
				pdfHelper.addRow(count++,"Product should exist with name "+"\""+expected+"\"", "Product exists with name "+"\""+actual+"\"", 2,file);
			}
		} else {
			
			String errorMsg = "//*[@id=\"content\"]/p[2]";
			expected = "There is no product that matches the search criteria.";

			actual = driver.findElement(By.xpath(errorMsg)).getText();
			
			file  = Helper.takeSnapShot(driver,"Step_"+count);
			if (expected.equals(actual)) {
				pdfHelper.addRow(count++,"Message Should be displayed as "+"\""+expected+"\"", "Message is displayed as "+"\""+actual+"\"", 1,file);
			} else {
				pdfHelper.addRow(count++,"Message Should be displayed as "+"\""+expected+"\"", "Message is displayed as "+"\""+actual+"\"", 2,file);
			}
		}
	}

	@Test(priority = 2)
	public void testStep3() throws Exception {

		Homepage home = new Homepage(driver);
		home.goToLogout(count++,pdfHelper);

		file = Helper.takeSnapShot(driver,"Step_"+count);
		//pdfHelper.addRow(count++,"test2", "test1", 2,file);
		
		String logOutMsg = "//p[contains(text(),'You have been logged off your account. It is now s')]";

		String actual = driver.findElement(By.xpath(logOutMsg)).getText();

		String expected = "You have been logged off your account. It is now safe to leave the computer.";

		if (expected.equals(actual)) {
			pdfHelper.addRow(count++,"Message Should be displayed as "+"\""+expected+"\"", "Message is displayed as "+"\""+actual+"\"", 1,file);
		} else {
			pdfHelper.addRow(count++,"Message Should be displayed as "+"\""+expected+"\"", "Message is displayed as "+"\""+actual+"\"", 2,file);
		}

	}

}
