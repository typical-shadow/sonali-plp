package com.opencart.pageobject;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.opencart.utilities.Helper;
import com.opencart.utilities.PDFHelper;

public class LoginPage {

	@FindBy(id = "input-email")
	private WebElement email;

	@FindBy(id = "input-password")
	private WebElement psswd;

	@FindBy(xpath = "//*[@id=\"content\"]/div/div[2]/div/form/input")
	private WebElement button;

	WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getPsswd() {
		return psswd;
	}

	public void setPsswd(WebElement psswd) {
		this.psswd = psswd;
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton(WebElement button) {
		this.button = button;
	}

	public void performLogin(String uname, String pass, int count,PDFHelper pdfHelper) throws Exception {
		email.clear();
		email.sendKeys(uname);
		psswd.clear();
		psswd.sendKeys(pass);
		
		File file = Helper.takeSnapShot(driver, "Step_" + count);
		pdfHelper.addRow(count, "Valid Data should enter", "Valid Data is entered", 1, file);
		
		button.click();
	}

}
